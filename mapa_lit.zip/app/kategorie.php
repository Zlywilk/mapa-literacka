<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class kategorie extends Model
{
    protected $table = "kategorie";
     protected $dateFormat = 'U';
}
