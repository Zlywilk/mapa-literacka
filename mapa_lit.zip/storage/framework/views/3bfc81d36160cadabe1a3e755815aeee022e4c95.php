
<?php $__env->startSection('title', $kmesage); ?>
<?php $__env->startSection('content'); ?>
<script>$('.ajax').colorbox();</script>
<?php foreach(array_chunk($marker->all(), 3) as $row): ?>
<div class="row center-block">
<?php foreach($row as $item): ?>
    <?php if($item->opis == ''): ?>
    <div class="col-xs-8 col-md-4"> <p><?php echo e($item->title); ?></p></div>
    <?php else: ?>
<div class="col-xs-8 col-md-4"> <a class="ajax" href="/markers/<?php echo e($item->id); ?>"><?php echo e($item->title); ?></a><br></div>
    <?php endif; ?>
    <?php endforeach; ?>
</div>
<?php endforeach; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.legenda', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>