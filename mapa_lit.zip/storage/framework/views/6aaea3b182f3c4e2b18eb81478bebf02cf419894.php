<style>
.gm-style > div:first-child > div + div > div:last-child > div > div:first-child > div
{
    /* we have to use !important because we are overwritng inline styles */
    background-color: transparent !important;
    box-shadow: none !important;
    width: auto !important;
    height: auto !important;
}

/* arrow colour */
.gm-style > div:first-child > div + div > div:last-child > div > div:first-child > div > div > div
{
    background-color: #000 !important; 
}
</style>
<div class="row">
<div class="container-fluid">
        <h4 style="margin:0px"><?php echo e($marker->title); ?></h4>
  <?php if($marker->opis !== ''): ?>
        <p style="margin:0px"><?php echo e($marker->opis); ?></p>
     <?php endif; ?>
          <?php if($marker->image !== NULL): ?>
    <img src="<?php echo e($marker->image); ?>" alt="<?php echo e($marker->title); ?>"><br>
<?php endif; ?>
                 <a class="myLink" href="<?php echo e($marker->latitude); ?>,<?php echo e($marker->longitude); ?>">pokaż punkt na mapie</a>
</div>
</div>