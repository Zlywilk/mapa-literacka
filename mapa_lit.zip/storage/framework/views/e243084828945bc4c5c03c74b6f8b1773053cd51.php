
<?php $__env->startSection('title', 'Legenda'); ?>
<?php $__env->startSection('content'); ?>
<script>$('.ajax').colorbox();

</script> 
<?php foreach(array_chunk($kategorie->all(), 3) as $row): ?>
<div class="row center-block">
<?php foreach($row as $item): ?>
<div class="col-xs-8 col-md-4">  <a class="ajax" href="category/<?php echo e(str_slug($item->opis)); ?>/<?php echo e($item->id); ?>"> <img src="<?php echo e($item->gfx); ?>" alt="<?php echo e($item->opis); ?>"><?php echo e($item->opis); ?> </a><input type="checkbox" value="<?php echo e($item->id); ?>" checked></div>
    <?php endforeach; ?>
</div>
<?php endforeach; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.legenda', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>