function init() {

    var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var labelIndex = 0;

    geocoder = new google.maps.Geocoder();
    // Basic options for a simple Google Map
    // For more options see: https://developers.google.com/maps/documentation/javascript/reference#MapOptions
    var mapOptions = {
        // How zoomed in you want the map to start at (always required)
        zoom: 14,

        // The latitude and longitude to center the map (always required)
        center: new google.maps.LatLng(53.0137902, 18.5984437), // Brodnica

        // Disables the default Google Maps UI components
        disableDefaultUI: true,
        scrollwheel: true,
        draggable: true,
        zoomControl: true,
        fullscreenControl: true



    };
    // Get the HTML DOM element that will contain your map
    // We are using a div with id="map" seen below in the <body>
    var mapElement = document.getElementById('map');

    // Create the Google Map using out element and options defined above
    var theMap = new google.maps.Map(document.getElementById('map'), mapOptions);


    var beachMarker = {
        1: [],
        2: [],
        3: [],
        4: [],
        5: [],
        6: [],
        7: [],
        8: [],
        9: [],
        10: []
    };
    var markersadd = [];
    // Custom Map Marker Icon - Customize the map-marker.png file to customize your icon
    $.get('markers', function(data, status) {
        var datl = data.length,
            i = 0;

        for (i; i < datl; i++) {
            var pozycja = new google.maps.LatLng(data[i].latitude, data[i].longitude);
            var markertitle = data[i].title;
            var markerid = data[i].id;
            var ktype = data[i].type;
            var image = {
                url: data[i].gfx,
                // This marker is 20 pixels wide by 32 pixels high.
                size: new google.maps.Size(40, 40),
                // The origin for this image is (0, 0).
                origin: null,
                // The anchor for this image is the base of the flagpole at (0, 32).
                anchor: null

            };

            bazamarkerow = new google.maps.Marker({
                position: pozycja,
                map: theMap,
                icon: image,
                title: markertitle,
                id: markerid,
                type: ktype
            });
            bindInfoWindow(bazamarkerow, theMap);
            var typ = bazamarkerow.type;
            beachMarker[typ].push(bazamarkerow);
        }

    });


    var bindInfoWindow = function(bazamarkerow, theMap) {
        google.maps.event.addListener(bazamarkerow, 'click', function() {
            var markerid = 'markers/' + bazamarkerow.id;
            var request = $.ajax({
                url: markerid,
                success: function(markercontent) {
                    var infowindow = new google.maps.InfoWindow({
                        content: markercontent
                    });
                    infowindow.open(theMap, bazamarkerow);

                }
            });


        });
    };

    function toggleGroup(type) {
        for (var i = 0; i < beachMarker[type].length; i++) {
            // alert(markerGroups[type][i]);
            var marker = beachMarker[type][i];
            if (!marker.getVisible()) {
                marker.setVisible(true);
            } else {
                marker.setVisible(false);
            }
        }
    }

    function visableAll() {
        for (var i = 1; i < 10; i++) {
            jd = beachMarker[i].length;
            for (j = 0; j < jd; j++) {
                var marker = beachMarker[i][j];
                if (!marker.getVisible()) {
                    marker.setVisible(true);
                }
                // alert(markerGroups[type][i]);

            }
        }
    }
    $('body').on('change', '#cboxLoadedContent input', function() {
        toggleGroup(this.value);
    });
    theMap.controls[google.maps.ControlPosition.TOP_CENTER].push(document.getElementById('legend'));

    $('body').on('change', 'input[name="title"]', function() {
        var fclosed = $(this).closest('.panel-body');
        fclosed.prev().html(this.value);
        if (fclosed.find('input[name="title"]').val() === '') {
            fclosed.prev().html('marker');
            fclosed.find('.error').append('zaraz chyba ktoś tu zapomniał o nazwie :)');
            fclosed.find('.error').fadeIn();
            return;
        } else {
            fclosed.find('.error').empty();
            fclosed.find('.error').fadeOut();
        }

    });
    $('body').on('change', 'select[name="type"]', function() {
        var fclosed = $(this).closest('.panel-body');
        fclosed.find('.error').empty();
        fclosed.find('.error').fadeOut();

    });
    google.maps.event.addListener(theMap, 'click', function(event) {
        addMarker(event.latLng, theMap);
    });

    function addMarker(location, map) {
        // Add the marker at the clicked location, and add the next-available label
        // from the array of alphabetical characters.
        var marker = new google.maps.Marker({
            position: location,
            label: labels[labelIndex++ % labels.length],
            map: map
        });
        lat = location.lat();
        lng = location.lng();
theMap.setCenter(location);
        markersadd.push(marker);
        iloscmarkerów = markersadd.length - 1;
        if (iloscmarkerów === 0) {
            $("input[name='latitude']:last").val(lat);
            $("input[name='longitude']:last").val(lng);
            $('#sidebar-wrapper').removeClass('hide');

        } else {

            $('#sidebar-wrapper').removeClass('hide');
            markeraddmenu = $('.panel').filter(':first').clone();
            markeraddmenu.find('.panel-heading').html('marker');
            markeraddmenu.find('alert-danger').hide();
            markeraddmenu.find('alert-danger').empty();
            markeraddmenu.find('.alert-danger').addClass('error' + iloscmarkerów);
                markeraddmenu.find('.alert-danger').removeClass('error0');

            markeraddmenu.find('.title').val('');
            markeraddmenu.find('.opis').val('');
            markeraddmenu.find('.type').select(0);
            $('.all').before(markeraddmenu);
            $("input[name='latitude']:last").val(lat);
            $("input[name='longitude']:last").val(lng);
        }
    };
    $('.city').click(function(e) {
        e.preventDefault();
        var city = $('#city').val() + ',87-100 Toruń';
        geocoder.geocode({
            'address': city
        }, function(results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                theMap.setCenter(results[0].geometry.location);
                addMarker(results[0].geometry.location, theMap);

            }
        });
    });

    $('#toggle').click(function() {
        $('#sidebar-wrapper').toggleClass('hide');
    });
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var toggle = document.getElementById('toggle');
    $('.ajax').on('click', function(e) {
        e.preventDefault();
        $('.ajax').colorbox();
        visableAll();
    });

    $('body').on('click', '.panel-heading', function() {

        $(this).next('div').slideToggle('slow');
    });

    $('body').on('click', '.send', function(e) {
        e.preventDefault();
        var formclose = $(this).closest('.panel-body');
        formclose.find('.error').empty();
        var frm = formclose.find('.form-group');
        if (formclose.find('input[name="title"]').val() === '') {
            formclose.find('.error').append('zaraz chyba ktoś tu zapomniał o nazwie :)');
            formclose.find('.error').fadeIn();
            return;
        }

        if (formclose.find('select[name="type"]').val() === null) {
            formclose.find('.error').append('a typ to kto wybierze :)');
            formclose.find('.error').fadeIn();
            return;
        }
        var data = JSON.stringify(frm.serializeObject());
        sendajax(data);


    });
    $('body').on('click', '.sendall', function(e) {
        e.preventDefault();
        var formclose = $('#uplo');

        var data = JSON.stringify(formclose.serializeObject());
        sendajax(data);


    });
    function sendajax(formdata) {
        $.ajax({
                type: 'post',
                url: 'markers',
                contentType: 'application/json',
            data: formdata,
                success: function(data) {
                    alert('ok');
                }
            })
            .error(function(data) {
            var erro = $('.error');
            var errol = erro.length;
                var errors = data.responseJSON;


                   $.each(errors, function(index, value) {
                        var split = index.split('.');

                       if (split[1] === undefined) {
                           $('.error0').append(value);
                           $('.error0').fadeIn();
                           return;
                       }else {

                              $('.error' + split[1]).append(value);
                         $('.error' + split[1]).fadeIn();

                   }

                   });
        });
    }
    $('body').on('change', 'input[type="checkbox"]', function() {

        this.value ^= 1;
    });
    $.fn.serializeObject = function() {
        var o = {};
        //    var a = this.serializeArray();
        $(this).find('input[type="hidden"], input[type="text"], input[type="password"], input[type="checkbox"], input[type="radio"]:checked, select, textarea').each(function() {
            if ($(this).attr('type') == 'hidden') { //if checkbox is checked do not take the hidden field
                var $parent = $(this).parent();
                var $chb = $parent.find('input[type="checkbox"][name="' + this.name.replace(/\[/g, '\[').replace(/\]/g, '\]') + '"]');
                if ($chb != null) {
                    if ($chb.prop('checked')) return;
                }
            }
            if (this.name === null || this.name === undefined || this.name === '')
                return;
            var elemValue = null;
            if ($(this).is('select'))
                elemValue = $(this).find('option:selected').val();
            else elemValue = this.value;
            if (o[this.name] !== undefined) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(elemValue || '');
            } else {
                o[this.name] = elemValue || '';
            }
        });
        return o;
    };

    theMap.controls[google.maps.ControlPosition.TOP_LEFT].push();

}

google.maps.event.addDomListener(window, 'load', init);
