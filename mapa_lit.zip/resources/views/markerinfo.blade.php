<style>
.gm-style > div:first-child > div + div > div:last-child > div > div:first-child > div
{
    /* we have to use !important because we are overwritng inline styles */
    background-color: transparent !important;
    box-shadow: none !important;
    width: auto !important;
    height: auto !important;
}

/* arrow colour */
.gm-style > div:first-child > div + div > div:last-child > div > div:first-child > div > div > div
{
    background-color: #000 !important; 
}
</style>
<div class="row">
<div class="container-fluid">
        <h4 style="margin:0px">{{$marker->title}}</h4>
  @if ($marker->opis !== '')
        <p style="margin:0px">{{$marker->opis}}</p>
     @endif
          @if ($marker->image !== NULL)
    <img src="{{$marker->image}}" alt="{{$marker->title}}"><br>
@endif
                 <a class="myLink" href="{{$marker->latitude}},{{$marker->longitude}}">pokaż punkt na mapie</a>
</div>
</div>