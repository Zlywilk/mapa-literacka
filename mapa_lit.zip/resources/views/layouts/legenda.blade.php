
        <h4>@yield('title')</h4>
               @yield('content')
